package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Student;
import com.example.demo.entity.Subject;
import com.example.demo.error.NotFoundException;

import com.example.demo.service.SubjectService;

@RestController
public class SubjectController {

	@Autowired
	private SubjectService subjectService;
	
	@PostMapping("/saveSubject")
	public ResponseEntity<Subject> addSubject(@Valid @RequestBody Subject subject) {
	Subject subject1=subjectService.addSubject(subject);	
		return new ResponseEntity<>(subject1,HttpStatus.CREATED);
	}
	
	@GetMapping("/getAllSubjects")	
	public List<Subject>getAllSubject(){
		return subjectService.getAllSubject();
	}
	
	@GetMapping("/getSubjectById/{subid}")
	public Subject getSubjectById(@PathVariable ("subid") Integer subid,@RequestBody Subject subject) throws NotFoundException {
		return subjectService.getSubjectById(subid,subject);
	}
	
	@GetMapping("/findBySubjectName/{subname}")
	public Optional<Subject> findBySujectName(@PathVariable ("subname") String subjectName) throws NotFoundException{
		return subjectService.findBySubjectName(subjectName);
	}
	
	@DeleteMapping("/deleteSubjectById/{subid}")
	public String deleteSubjectById(@PathVariable("subid") Integer subid , @RequestBody Subject subject) throws NotFoundException {
		subjectService.deleteSubjectById(subid,subject);
		return "Subject record is deleted";	
	}
	
	@PutMapping("/updateSubjectById/{subid}")
	public Subject updateSubject(@PathVariable("subid") Integer subid,@RequestBody Subject subject) throws NotFoundException {
		return subjectService.updateSubject(subid,subject);
	}
	
	@PutMapping("/subject/{subid}/student/{stuid}")
	public Subject enrolledStudentsToSubject(@PathVariable ("subid")Integer subid,@PathVariable("stuid") Integer stuid) throws NotFoundException, NotFoundException {
		return subjectService.enrolledStudentsToSubject(subid,stuid);
	}
	
	@PutMapping("/subject/{subid}/teacher/{tid}")
	public Subject assignSubjectToTeacher(@PathVariable("subid")Integer subid,@PathVariable("tid")Integer tid) throws NotFoundException, NotFoundException {
		return subjectService.assignSubjectToTeacher(subid,tid);
	}
}
