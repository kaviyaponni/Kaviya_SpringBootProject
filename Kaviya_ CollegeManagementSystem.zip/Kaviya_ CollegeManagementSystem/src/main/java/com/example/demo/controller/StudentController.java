package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.entity.Student;
import com.example.demo.error.NotFoundException;
import com.example.demo.repository.StudentRepository;
import com.example.demo.repository.TeacherRepository;
import com.example.demo.service.StudentService;

@RestController

public class StudentController {
	@Autowired
	private StudentService studentService;
	
	@Autowired
	private StudentRepository studentRepository;
	
	@PostMapping("/saveStudent")
	public ResponseEntity<Student> addStudent(@Valid @RequestBody Student student) {
		Student student1=studentService.addStudent(student);
		return new ResponseEntity<>(student1,HttpStatus.CREATED);	
	}
		
	@GetMapping("/getAllStudents")
	public List<Student> getAllStudents(){
		return studentService.getAllStudents();
	}

	@GetMapping("/getStudentById/{sid}")
	public Student getStudentById(@PathVariable("sid") Integer sid) throws NotFoundException {
		return  studentService.getStudentById(sid);
	}
	
	@GetMapping("/findByStudentName/{sname}")
	public List<Student> findByStudentName(@PathVariable ("sname") String studentName) throws NotFoundException{
		return studentService.findByStudentName(studentName);
	}
	
	@DeleteMapping("/deleteStudentById/{sid}")
	public String deleteStudentById(@PathVariable("sid") Integer sid) throws NotFoundException {
		studentService.deleteStudentById(sid);
		return "Record is deleted";
	}
	
	@PutMapping("/updateStudentById/{sid}")
	public Student updateStudent(@PathVariable("sid") Integer sid, @RequestBody Student student ) throws NotFoundException {
		return studentService.updateStudent(sid,student);
	}
	
	@GetMapping("/studentTotalFees")
	 public float studentTotalFees() {
		 return studentRepository.totalFees();
	 }
}
